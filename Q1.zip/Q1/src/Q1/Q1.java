/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q1;

/**
 *
 * @author abrar
 */
public class Q1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      employee e=new employee("Full time","Abrar","Devloper",10000.0,5,"Bachelor");
    }
    
}
